"""Replay the filtered SBKK product-support calculation without h5py.

Paths are anchored to this file; the working directory is irrelevant.
All numerical inputs are lossless slices of the original cum_filt.h5.
"""
from pathlib import Path
import argparse
import hashlib
import json
import platform

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_manifest():
    manifest = json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))
    for item in manifest["files"]:
        path = ROOT / item["path"]
        if path.stat().st_size != item["bytes"] or sha256(path) != item["sha256"]:
            raise ValueError("Bundle integrity check failed: " + item["path"])
    return len(manifest["files"])


def write_original_json(path, value):
    # Original author outputs used CRLF; explicit bytes are portable across OSes.
    path.write_bytes(json.dumps(value, indent=2).replace("\n", "\r\n").encode("utf-8"))


def replay(output):
    grid = json.loads((ROOT / "input" / "geometry.json").read_text(encoding="utf-8"))
    provenance = json.loads((ROOT / "provenance.json").read_text(encoding="utf-8"))
    window = provenance["extraction"]["window_zero_based_half_open"]
    r0, r1 = window["rows"]
    c0, c1 = window["columns"]
    with np.load(ROOT / "input" / "sbkk_filtered_window.npz", allow_pickle=False) as data:
        dates = pd.to_datetime([str(v) for v in data["imdates"]], format="%Y%m%d")
        cum, mask, velocity = data["cum"], data["mask"], data["vel"]
    assert cum.shape == (len(dates), r1 - r0, c1 - c0)
    assert mask.shape == velocity.shape == (r1 - r0, c1 - c0)
    lat = 13 + 47 / 60 + 34.59825 / 3600
    lon = 100 + 35 / 60 + 47.37945 / 3600
    a, b, x0, d, e, y0 = grid["transform"]
    assert b == d == 0, "Original audit assumes an unrotated geographic grid"
    rows, cols = np.indices(grid["shape"])
    xs = x0 + (cols + 0.5) * a
    ys = y0 + (rows + 0.5) * e
    distance_m = np.hypot((xs - lon) * 108000, (ys - lat) * 111000)
    within_full = distance_m <= 100
    nearest_row, nearest_col = np.unravel_index(np.argmin(distance_m), distance_m.shape)
    point_offset = float(distance_m[nearest_row, nearest_col])
    assert r0 <= nearest_row < r1 and c0 <= nearest_col < c1
    within_100m = within_full[r0:r1, c0:c1]
    assert int(within_100m.sum()) == int(within_full.sum()), "Window omits radius members"
    supported = within_100m & (mask > 0)
    # Same float32 arithmetic, date basis, fit and percentile definitions as the original.
    series = np.nanmedian(np.where(supported[None, :, :], cum, np.nan), axis=(1, 2))
    time_years = (dates - dates[0]).days / 365.25
    valid_dates = np.isfinite(series)
    rate = float(np.polyfit(time_years[valid_dates], series[valid_dates], 1)[0])
    frame = pd.DataFrame({
        "date": dates.date.astype(str),
        "median_cum_los_mm_within_100m": series,
        "valid_pixel_centers_within_100m": int(supported.sum()),
    })
    summary = {
        "station": "SBKK (RTSD CORS)",
        "coordinate_dd": {"latitude": lat, "longitude": lon},
        "coordinate_source": "JICA National CORS Data Center report, Table 5; source https://openjicareport.jica.go.jp/pdf/12386280_01.pdf",
        "insar_stack": {
            "n_acquisitions": int(len(dates)),
            "first_date": dates.min().date().isoformat(),
            "last_date": dates.max().date().isoformat(),
            "nearest_pixel_center_offset_m": point_offset,
            "nearest_pixel_center_valid": bool(mask[nearest_row - r0, nearest_col - c0] > 0),
            "pixel_centers_within_100m": int(within_100m.sum()),
            "valid_pixel_centers_within_100m": int(supported.sum()),
            "median_velocity_los_mm_yr": float(np.nanmedian(velocity[supported])),
            "q25_velocity_los_mm_yr": float(np.nanpercentile(velocity[supported], 25)),
            "q75_velocity_los_mm_yr": float(np.nanpercentile(velocity[supported], 75)),
            "median_cumulative_los_rate_mm_yr": rate,
            "cumulative_series_range_mm": float(np.nanmax(series) - np.nanmin(series)),
        },
        "scope": "Product-specific support audit only. No SBKK GNSS time series was recovered or compared. The LiCSAR LOS rate is not a vertical rate and is not directly comparable with the published SBKK ellipsoidal-height rate.",
    }
    output.mkdir(parents=True, exist_ok=True)
    frame.to_csv(output / "SBKK_100m_LiCSAR.csv", index=False, lineterminator="\r\n")
    write_original_json(output / "SBKK_support_summary.json", summary)
    return summary


def compare_reference(output):
    comparisons = []
    for name in ("SBKK_100m_LiCSAR.csv", "SBKK_support_summary.json"):
        actual = output / name
        reference = ROOT / "reference_results" / name
        equal = actual.read_bytes() == reference.read_bytes()
        comparisons.append({"file": name, "byte_identical": equal,
                            "actual_sha256": sha256(actual), "reference_sha256": sha256(reference)})
    return comparisons


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "results" / "gnss_feasibility",
                        help="Destination for the two replayed audit outputs")
    args = parser.parse_args()
    manifest_count = check_manifest()
    summary = replay(args.output)
    comparisons = compare_reference(args.output)
    passed = all(item["byte_identical"] for item in comparisons)
    report = {"status": "PASS" if passed else "FAIL", "verified_manifest_files": manifest_count,
              "environment": {"python": platform.python_version(), "numpy": np.__version__, "pandas": pd.__version__},
              "reference_comparisons": comparisons, "insar_stack": summary["insar_stack"],
              "scope": summary["scope"]}
    (args.output / "replay_verification.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    if not passed:
        raise SystemExit("Outputs differ from the original references. Use requirements.txt and the documented Python version.")


if __name__ == "__main__":
    main()
