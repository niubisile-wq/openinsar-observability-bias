SBKK filtered-product support audit | 2026-10-03

This companion to the current manuscript and SI S3 supplies the filtered local
inputs missing from the fixed public v0.6.0 distribution. It is separate from
Local_Validation_Audit.zip, which covers CUSV/CUUT. Neither archive is silently
added to, or claimed to be part of, the historical public v0.6.0 release.

Scope
This is a product-specific support audit only. No SBKK GNSS time series was
recovered or compared. It does not establish GNSS accuracy or validate absolute
vertical land motion. LiCSAR LOS positive-toward-satellite velocity cannot be
compared directly with a published ellipsoidal-height/vertical rate. The original
audit's approximate distance convention and 365.25-day fitted-rate basis are
preserved, not substituted by a different geodesic or regression definition.

Quick replay (Python 3.10.11 tested)
1. Unzip SBKK_Support_Audit.zip, preserving its top-level directory.
2. In a Python environment, run:
       python -m pip install -r /path/to/SBKK_Support_Audit/requirements.txt
3. From ANY working directory, run:
       python /path/to/SBKK_Support_Audit/reproduce_sbkk_support.py
   Windows paths can be quoted normally. Optional --output /path/to/output sets
   a custom output directory. The default is results/gnss_feasibility inside
   the extracted bundle. Existing files with these output names are overwritten.

No h5py, LiCSBAS installation, full HDF5, network access, source workspace,
INSAR_CORE_ROOT variable or raw-processing rerun is required for replay.
The runtime dependencies are only numpy and pandas, plus Python's standard
library. The pinned environment is used for the byte-identical reference check.
The installation command may need network access only to install dependencies.

The script verifies manifest hashes, calculates distances on the whole original
geometry grid, checks that the slice contains ALL 100 m members and the globally
nearest center, applies the original final mask, and reproduces the full 104-row
CSV and all fields of the JSON summary. It compares both output files byte for
byte with the original references and exits nonzero on mismatch. Original CRLF
line endings are explicitly preserved to make serialization independent of OS.
replay_verification.json reports environment, hashes and PASS/FAIL.

Expected original results
  Acquisitions: 104, from 2019-01-04 through 2020-12-30
  Nearest pixel center: 44.778795348814086 m; final mask valid
  Pixel centers within 100 m: 2; final-mask-valid centers: 2
  Filtered median LOS velocity: 2.314016580581665 mm/year
  Fitted median cumulative LOS rate: 2.314016538340285 mm/year
The supplied references also retain both velocity quartiles and the series range.
No numerical values were adjusted to satisfy these reported results.

Contents
  reproduce_sbkk_support.py         portable, h5py-free replay and verification
  requirements.txt                 tested pinned replay dependencies
  input/sbkk_filtered_window.npz    lossless original cum, vel, mask and imdates
  input/geometry.json              unchanged original grid geometry/metadata
  input/acquisition_dates.csv      readable copy of all 104 dates
  reference_results/               unchanged original CSV and JSON results
  provenance.json                  original source hashes, exact extraction rule,
                                   slice bounds, dtypes, shapes, array-byte hashes
  manifest.json                    SHA256 and size of every other shipped file
  source/original_audit_sbkk_support.py
                                   unchanged historical source (not the portable entry)
  source/extract_sbkk_support.py    builder used to extract the inputs and archive

The NPZ stores the native float32 arrays without rounding or dtype conversion,
and the native int32 dates. The selected rectangle includes every 100 m member
and the globally nearest pixel plus a one-pixel border. Final mask and velocity
come from the SAME filtered cum_filt.h5 as the cumulative series. The original
geometry transform is used with GLOBAL row/column indices. The unfiltered
matched_quality.npz and cum.h5 are not inputs to this bundle; their approximately
2.4527 mm/year statistic is not a replacement for the reported filtered value.

Extraction provenance and regeneration
provenance.json identifies the SHA256 of the complete original cum_filt.h5,
geometry, audit script and two reference outputs. Dataset-byte hashes record
the exact uncompressed slice. NPZ round-trip bytes were checked at extraction.
The full HDF5 is not included; it is needed only to independently repeat the
extraction, not to replay the calculation. Extraction requires h5py==3.16.0 in
addition to the pinned replay dependencies and was tested with Python 3.10.11.

To rebuild from the author's original strengthening tree, retain the reviewed
README, requirements and replay script in a bundle directory, then run:
  python source/extract_sbkk_support.py --source-root /path/to/strengthening \
    --bundle /path/to/SBKK_Support_Audit --zip /path/to/SBKK_Support_Audit.zip
The backslash above is a display line continuation for a Unix shell; on Windows
place the command on one line. This reads the old source tree without editing it.
It does not rerun the InSAR processing chain or regenerate the reference files.

Coordinate provenance
The original RTSD/National CORS Data Center SBKK coordinate and attribution to
JICA report Table 5 are preserved in the original script and summary:
https://openjicareport.jica.go.jp/pdf/12386280_01.pdf
This bundle preserves that existing coordinate attribution; it does not contain
SBKK GNSS observations. Source geometry preserves the original LiCSBAS upstream
commit and processing conventions. The original broader project licensing and
third-party attribution remain applicable; no new provider-rights claim is made.
