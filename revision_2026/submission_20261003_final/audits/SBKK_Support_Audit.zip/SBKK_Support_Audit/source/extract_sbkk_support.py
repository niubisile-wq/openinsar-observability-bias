"""Extract and package the original filtered SBKK inputs without changing them.

Requires h5py only for extraction. The delivered replay uses numpy and pandas.
This script reads the author's source tree and writes only to --bundle and --zip.
README.txt, requirements.txt and reproduce_sbkk_support.py must already exist in
the bundle (they are the reviewed portable implementation, not generated data).
"""
from pathlib import Path
import argparse
import hashlib
import json
import platform
import shutil
import zipfile

import h5py
import numpy as np
import pandas as pd


def file_hash(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def array_hash(array):
    return hashlib.sha256(np.ascontiguousarray(array).tobytes()).hexdigest()


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def build(source, bundle, archive):
    for name in ("README.txt", "requirements.txt", "reproduce_sbkk_support.py"):
        if not (bundle / name).is_file():
            raise FileNotFoundError("Reviewed bundle asset missing: " + str(bundle / name))
    for name in ("input", "reference_results", "source"):
        (bundle / name).mkdir(parents=True, exist_ok=True)
    source_paths = [
        "results/timeseries/TS_full/cum_filt.h5",
        "results/timeseries/geometry.json",
        "audit_sbkk_support.py",
        "results/gnss_feasibility/SBKK_100m_LiCSAR.csv",
        "results/gnss_feasibility/SBKK_support_summary.json",
    ]
    sources = [{"path_relative_to_author_strengthening": path,
                "bytes": (source / path).stat().st_size, "sha256": file_hash(source / path)}
               for path in source_paths]
    grid_path = source / "results/timeseries/geometry.json"
    grid = json.loads(grid_path.read_text(encoding="utf-8"))
    a, b, x0, d, e, y0 = grid["transform"]
    assert b == d == 0
    lat = 13 + 47 / 60 + 34.59825 / 3600
    lon = 100 + 35 / 60 + 47.37945 / 3600
    rows, cols = np.indices(grid["shape"])
    distances = np.hypot((x0 + (cols + 0.5) * a - lon) * 108000,
                         (y0 + (rows + 0.5) * e - lat) * 111000)
    within = distances <= 100
    nearest = np.unravel_index(np.argmin(distances), distances.shape)
    keep_rows, keep_cols = np.where(within)
    keep_rows = np.append(keep_rows, nearest[0])
    keep_cols = np.append(keep_cols, nearest[1])
    r0, r1 = max(0, int(keep_rows.min()) - 1), min(grid["shape"][0], int(keep_rows.max()) + 2)
    c0, c1 = max(0, int(keep_cols.min()) - 1), min(grid["shape"][1], int(keep_cols.max()) + 2)
    assert int(within[r0:r1, c0:c1].sum()) == int(within.sum())
    with h5py.File(source / source_paths[0], "r") as handle:
        assert tuple(grid["shape"]) == handle["mask"].shape
        arrays = {
            "cum": handle["cum"][:, r0:r1, c0:c1],
            "vel": handle["vel"][r0:r1, c0:c1],
            "mask": handle["mask"][r0:r1, c0:c1],
            "imdates": handle["imdates"][:],
        }
        datasets = {key: {"source_shape": list(handle[key].shape),
                          "source_dtype": str(handle[key].dtype),
                          "extracted_shape": list(value.shape),
                          "extracted_dtype": str(value.dtype),
                          "extracted_c_order_bytes_sha256": array_hash(value)}
                    for key, value in arrays.items()}
        supported = within[r0:r1, c0:c1] & (arrays["mask"] > 0)
        source_check = {
            "n_acquisitions": len(arrays["imdates"]),
            "nearest_global_row_column": [int(v) for v in nearest],
            "nearest_pixel_center_offset_m": float(distances[nearest]),
            "pixel_centers_within_100m": int(within.sum()),
            "valid_pixel_centers_within_100m": int(supported.sum()),
            "median_velocity_los_mm_yr": float(np.nanmedian(arrays["vel"][supported])),
        }
    npz_path = bundle / "input/sbkk_filtered_window.npz"
    np.savez_compressed(npz_path, **arrays)
    with np.load(npz_path, allow_pickle=False) as saved:
        for key, value in arrays.items():
            assert saved[key].dtype == value.dtype and saved[key].shape == value.shape
            assert saved[key].tobytes() == value.tobytes(), "Lossless round trip failed: " + key
    shutil.copyfile(grid_path, bundle / "input/geometry.json")
    dates = pd.to_datetime([str(v) for v in arrays["imdates"]], format="%Y%m%d")
    pd.DataFrame({"imdate": arrays["imdates"], "date": dates.date.astype(str)}).to_csv(
        bundle / "input/acquisition_dates.csv", index=False, lineterminator="\n")
    for name in ("SBKK_100m_LiCSAR.csv", "SBKK_support_summary.json"):
        shutil.copyfile(source / "results/gnss_feasibility" / name, bundle / "reference_results" / name)
    shutil.copyfile(source / "audit_sbkk_support.py", bundle / "source/original_audit_sbkk_support.py")
    builder_copy = bundle / "source/extract_sbkk_support.py"
    if Path(__file__).resolve() != builder_copy.resolve():
        shutil.copyfile(__file__, builder_copy)
    provenance = {
        "bundle": "SBKK_Support_Audit", "version": "2026-10-03",
        "scope": "Product-specific support audit only; not a GNSS accuracy or vertical-motion validation.",
        "source_product": "Filtered LiCSBAS TS_full/cum_filt.h5; not unfiltered cum.h5 or matched_quality.npz.",
        "sources": sources,
        "extraction": {
            "rule": "On the complete original geometry grid, calculate the original audit's approximate metric distance (longitude difference * 108000, latitude difference * 111000). Find every center <=100 m and the globally nearest center. Extract their minimal bounding rectangle expanded by one pixel on each side, clipped to source grid bounds. Slice cum on all original dates; slice final mask and vel identically. Copy every imdates value. No rounding, resampling, filtering, fitting, interpolation, or value replacement is applied to the input arrays.",
            "window_zero_based_half_open": {"rows": [r0, r1], "columns": [c0, c1]},
            "full_grid_shape": grid["shape"],
            "all_radius_members_present": True,
            "npz_lossless_c_order_bytes_verified": True,
            "dataset_metadata": datasets,
        },
        "original_coordinate": {"latitude": lat, "longitude": lon},
        "source_array_check": source_check,
        "extraction_environment": {"python": platform.python_version(), "numpy": np.__version__,
                                   "pandas": pd.__version__, "h5py": h5py.__version__},
        "reference_policy": "The two reference results and original audit script are copied byte for byte from the author source; they are not regenerated or edited to match the new replay.",
    }
    write_json(bundle / "provenance.json", provenance)
    # Runtime products are excluded from the distribution and integrity manifest.
    files = sorted(p for p in bundle.rglob("*") if p.is_file()
                   and p.name != "manifest.json" and "__pycache__" not in p.parts
                   and "results" not in p.relative_to(bundle).parts)
    manifest = {"algorithm": "SHA256", "files": [
        {"path": p.relative_to(bundle).as_posix(), "bytes": p.stat().st_size, "sha256": file_hash(p)}
        for p in files]}
    write_json(bundle / "manifest.json", manifest)
    archive.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
        for path in sorted(files + [bundle / "manifest.json"]):
            relative = (Path(bundle.name) / path.relative_to(bundle)).as_posix()
            info = zipfile.ZipInfo(relative, (2026, 10, 3, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            zipped.writestr(info, path.read_bytes())
    result = {"archive": str(archive), "bytes": archive.stat().st_size, "sha256": file_hash(archive),
              "archive_files": len(files) + 1, "source_array_check": source_check,
              "window": provenance["extraction"]["window_zero_based_half_open"]}
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", required=True, type=Path, help="Original strengthening directory")
    parser.add_argument("--bundle", required=True, type=Path, help="Reviewed SBKK_Support_Audit directory")
    parser.add_argument("--zip", required=True, type=Path, help="Destination archive")
    arguments = parser.parse_args()
    build(arguments.source_root.resolve(), arguments.bundle.resolve(), arguments.zip.resolve())
