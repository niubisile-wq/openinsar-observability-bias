"""Recompute a documented feasibility screen; no common-datum accuracy is claimed.

Requirements: Python 3.10+, numpy, pandas. Run from any working directory.
Station windows are lossless subsets of the archived filtered LiCSBAS cube.
"""
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
INPUT, OUT = ROOT / 'inputs', ROOT / 'results'
OUT.mkdir(parents=True, exist_ok=True)
manifest = json.loads((INPUT / 'source_manifest.json').read_text(encoding='utf-8'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
summaries = []
for station, loc in manifest['stations'].items():
    raw_path, window_path = INPUT / f'{station}.tenv3', INPUT / f'{station}_insar_window.npz'
    assert sha(raw_path) == loc['daily_series_sha256']
    assert sha(window_path) == loc['window_sha256']
    d = pd.read_csv(raw_path, sep=r'\s+', comment='#')
    d['date'] = pd.to_datetime(d['YYMMMDD'], format='%y%b%d')
    for component, integer, fraction in [('E','_e0(m)','__east(m)'),('N','____n0(m)','_north(m)'),('U','u0(m)','____up(m)')]:
        d[component] = (d[integer] + d[fraction])*1000
    d['los_mm'] = d[list('ENU')].to_numpy() @ np.array(loc['los_unit_vector_ENU'])
    windows = np.load(window_path)
    dates = pd.to_datetime(windows['dates'], format='%Y%m%d')
    cube, mask = windows['cumulative_mm'], windows['mask']
    point = cube[:,1,1].astype(float)
    median = np.nanmedian(np.where(mask[None,:,:] > 0, cube, np.nan), axis=(1,2))
    for radius_days in [0, 7]:
        sampled, n_days = [], []
        for date in dates:
            selected = d.loc[(d.date >= date-pd.Timedelta(days=radius_days)) &
                             (d.date <= date+pd.Timedelta(days=radius_days))]
            sampled.append(float(selected.los_mm.median()) if len(selected) else np.nan)
            n_days.append(len(selected))
        g = np.asarray(sampled)
        records = pd.DataFrame({'date':dates.strftime('%Y-%m-%d'), 'gnss_projected_los_mm':g,
            'gnss_days_in_window':n_days, 'insar_point_cum_mm':point,
            'insar_3x3_median_cum_mm':median})
        records.to_csv(OUT / f'{station}_{radius_days}day_matches.csv', index=False)
        for mode, values in [('containing_cell', point), ('3x3_median', median)]:
            ok = np.isfinite(g) & np.isfinite(values)
            t = (dates[ok]-dates[ok][0]).days.to_numpy()/365.25
            # Subtract the first epoch for numerical stability only. This does
            # NOT remove motion of the InSAR reference area or align datums.
            gnss = g[ok]-g[ok][0]
            insar = values[ok]-values[ok][0]
            gi, ii = np.polyfit(t,gnss,1), np.polyfit(t,insar,1)
            gres, ires = gnss-np.polyval(gi,t), insar-np.polyval(ii,t)
            summaries.append({'station':station,'date_window_days':radius_days,
                'spatial_sample':mode,'matched_acquisitions':int(ok.sum()),'total_acquisitions':len(dates),
                'center_offset_m':loc['cell_center_offset_m'],
                'insar_relative_trend_mm_yr':float(ii[0]),
                'gnss_global_frame_projected_trend_mm_yr':float(gi[0]),
                'first_epoch_aligned_RMSE_mm_DIAGNOSTIC_ONLY':float(np.sqrt(np.mean((gnss-insar)**2))),
                'separately_detrended_RMSE_mm_DIAGNOSTIC_ONLY':float(np.sqrt(np.mean((gres-ires)**2))),
                'common_datum_established':False,'independent_validation_eligible':False})
pd.DataFrame(summaries).to_csv(OUT / 'local_feasibility_summary.csv', index=False)
coords = list(manifest['stations'].values())
separation = float(np.hypot((coords[0]['longitude']-coords[1]['longitude'])*111320*np.cos(np.deg2rad(coords[0]['latitude'])),
                           (coords[0]['latitude']-coords[1]['latitude'])*111320))
checks = {'two_stations_one_spatial_location':True, 'station_separation_m':separation,
    'containing_pixel': [coords[0]['row'],coords[0]['column']],
    'both_stations_in_same_containing_pixel':all((x['row'],x['column'])==(coords[0]['row'],coords[0]['column']) for x in coords),
    'official_signed_ENU_used':True,'declared_sampling_options_all_retained':True,
    'date_window_options_exploratory_not_preregistered':[0,7],
    'frame_calibration_or_ramp_fit_performed':False,'independent_local_accuracy_established':False,
    'interpretation':'A feasibility audit. Raw global-frame GNSS and internal-reference InSAR trends are not accuracy scores. Detrending is not a common-datum correction.',
    'legacy_screen_corrections':['Replaced rounding of raster-corner indices with the containing cell.',
                               'Replaced heading-derived horizontal LOS coefficients with official signed E/N/U components.'],
    'primary_and_California_results_changed':False}
assert checks['both_stations_in_same_containing_pixel'] and separation < 10
(OUT / 'eligibility_check.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
print(pd.DataFrame(summaries).to_string(index=False))
print(json.dumps(checks,indent=2))
