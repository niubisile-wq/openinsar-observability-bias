Bangkok GNSS feasibility audit accompanying Supplementary S17
============================================================

This is a feasibility screen, not independent validation of Bangkok deformation.
It supplements the manuscript locally. It is not part of the unchanged public
scientific release v0.6.0, and has not been uploaded by this editing step.

REPLAY
------
Use Python 3.10 or later and install requirements.txt. Then run:

    python reproduce_local_feasibility.py

The script locates inputs relative to its own path and runs from any working
directory. No account, network connection, absolute project path, HDF5 library
or complete processing stack is needed to replay the reported feasibility
screen. It checks the frozen GNSS and InSAR-window SHA-256 hashes before use.

INPUTS AND EXTRACTION
--------------------
inputs/CUSV.tenv3 and CUUT.tenv3 are the archived NGL IGS20 daily series, retained
as downloaded in the earlier project. Integer and fractional ENU columns are
added, converted from metres to millimetres, and projected using official signed
LiCSAR coefficients. Full source URLs and hashes are in source_manifest.json.
Station coordinates are longitude-normalized to the geographic raster.

The two .npz files retain all 104 dates and unmodified 3-by-3 cumulative, mask and
velocity windows from the archived full-stack filtered LiCSBAS cum_filt.h5.
They contain identical pixel arrays because both stations occupy the same cell.
These are lossless subsets, not new inversions or deformation reconstructions.
The source HDF5 and original raster hashes allow extraction to be checked
against the parent processing archive. The full HDF5 and official geometry
rasters are not duplicated in this small supplement. The project script
scripts/prepare_local_validation_inputs.py records the extraction route; it
requires the separately retained parent processing data, h5py and rasterio.

Containing-cell selection uses the recorded affine transform and floor indices.
Both stations fall at zero-based row 314, column 184. The cell center is
100.5336097965 E, 13.73555654675 N. Approximate center offsets are 52.16 and
59.80 m. The inter-station separation is approximately 8.63 m.

The official descending-frame LOS coefficients sampled at the sites are:
    E = +0.5948997139930725
    N = -0.1175040751695633
    U = +0.7951648235321045
Positive displacement is toward the satellite. No heading-derived horizontal
sign convention is substituted for these source coefficients.

ALL EXPLORATORY SAMPLING OPTIONS ARE RETAINED
--------------------------------------------
Each station is evaluated at its containing cell and as the median over final-
mask-valid pixels in its 3-by-3 window. Both an exact UTC calendar-date match and
a median over plus/minus seven calendar days are reported. Daily GNSS solutions
are daily estimates, not instantaneous measurements at the radar acquisition
time. The date windows are exploratory choices, not preregistered settings.

CUSV has 97 exact-date and 101 seven-day-window matches out of 104 acquisitions.
CUUT has 66 and 77, respectively. Missing dates remain missing. All eight
station/window/spatial combinations are in local_feasibility_summary.csv.

WHY THESE ARE NOT ACCURACY SCORES
-------------------------------
NGL series use a global reference frame. The LiCSBAS cumulative displacement is
relative to an internal full-stack reference area, 145:146/225:226. These two
near-colocated stations do not provide two independent spatial sites or an
independent calibration plus validation split. We have not established the
motion of that reference area in the GNSS frame. There is no datum correction,
spatial ramp fit, station selection by residual, or claimed regional accuracy.

The output explicitly labels frame-specific trends, first-epoch-aligned RMSE
and separately detrended RMSE as DIAGNOSTIC_ONLY. First-epoch alignment removes
a constant, not reference-area motion. Separate detrending removes part of the
signal under comparison and cannot establish a common physical datum. These
numbers are therefore not used as accuracy claims in the manuscript. This
screen also cannot validate velocities in permanently unsupported pixels.

CORRECTION OF THE EARLIER UNPUBLISHED SCREEN
------------------------------------------
The earlier local gnss_feasibility diagnostic used rounding of raster-corner
indices, choosing column 185, and heading-derived horizontal LOS coefficients
with opposite signs to the official E/N fields. This supplement uses affine
containment (column 184) and official signed E/N/U coefficients instead. The
old files remain preserved as a historical diagnostic; their trends/residuals
must not be used as validation. They were not the source of the manuscript's
primary allocation results or its California GNSS comparison. Neither of those
experiments nor any of the nine main figures has been changed by this audit.

SOURCE ACCESS
-------------
NGL station pages:
https://geodesy.unr.edu/NGLStationPages/stations/CUSV.sta
https://geodesy.unr.edu/NGLStationPages/stations/CUUT.sta
Daily-series and COMET LiCSAR metadata URLs are recorded per file in
inputs/source_manifest.json. Provider terms govern third-party data reuse.
Official E/N rasters were retrieved on 2026-10-03; the audit reuses the archived
U raster and the frozen GNSS series to keep the processing evidence stable.
