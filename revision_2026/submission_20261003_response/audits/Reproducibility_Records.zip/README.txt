Reproducibility records accompanying S4 and S5

section_output_index.json maps S1-S31 to paths relative to the repository root at
https://github.com/niubisile-wq/openinsar-observability-bias/tree/v0.6.3
The full reference tables are provided by that fixed release, not duplicated in this ZIP.
Scientific calculations and numerical references retain the corrected v0.6.0 baseline.

supporting_records/ retains the original calculation summary and four-row published
Bangkok comparison table, its source audit and byte-level provenance. The source thesis
PDF is not redistributed. These literature summaries do not constitute independent
matched Bangkok accuracy validation. The two portable audit ZIPs are supplied separately.
