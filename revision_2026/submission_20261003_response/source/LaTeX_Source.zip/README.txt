Final revision sources, 3 October 2026; document snapshot v0.6.3

Main entry: manuscript.tex (clean main article). Supplement: supplementary.tex.
Response: response.tex. Cover letter: cover_letter.tex.
manuscript_numbered.tex adds line numbers to the same current main article.

Compile main, numbered main and SI with pdflatex, bibtex, pdflatex, pdflatex.
Compile response and cover letter with pdflatex twice. Preserve the figures/ directory.
The archive includes required local class/style files, bibliography and figure assets.
For journal main-file upload use Main_Article_Source.zip with its single main entry.
Figure filenames retain source provenance; publication numbering follows manuscript order.

Response presentation patch v0.6.4, 3 October 2026.
Only response.tex is shortened; redundant response_locations.tex is omitted.
The other source members, scientific text and figures are unchanged from v0.6.3.
Main/SI references to v0.6.3 remain the fixed scientific reproduction release.
