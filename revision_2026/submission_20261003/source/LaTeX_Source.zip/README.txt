Current submission source, 3 October 2026

Main entry: manuscript.tex (clean main article).
Supplementary entry: supplementary.tex.
Response: response.tex. Cover letter: cover_letter.tex.
manuscript_numbered.tex differs from the clean main only by the lineno class option.

Compile main/SI with pdflatex, bibtex, pdflatex, pdflatex.
Compile response/cover with pdflatex twice. All required figures and input TeX files are included.
Figure filenames preserve source provenance; their current publication numbers follow source order.
For journal main-file upload use Main_Article_Source.zip, which contains only the main entry and dependencies.
