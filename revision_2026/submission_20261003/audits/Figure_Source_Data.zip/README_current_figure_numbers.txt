Figure source-data numbering for the 3 October 2026 submission

The retained CSV filenames and source_manifest.json use the preceding manuscript
numbering. They are preserved to keep their byte-level provenance. Current numbers:

Current main Fig. 1 = preceding main Fig. 1 (workflow; conceptual diagram).
Current main Fig. 2 = preceding main Fig. 3; Figure_3_display_values.csv.
Current main Fig. 3 = preceding main Fig. 4; core/fine/support_curves.csv.
Current main Fig. 4 = preceding main Fig. 5; core/sampling conditional and nested tables.
Current main Fig. 5 = preceding main Fig. 7; core/allocation, core/dwr and
  additional/new_regions tables.
Current main Fig. 6 = preceding main Fig. 8; additional/gnss_transfer table.
Current Supplementary Fig. S6 = preceding main Fig. 6;
  core/sampling/spatial_rank_stability.csv.

The preceding main Figs. 2 and 9 are now Supplementary Figs. S1 and S20.
They are definition/evidence diagrams and introduce no additional numerical data.
The complete table paths for Supplementary S1-S31 are supplied separately in
Reproducibility_Records.zip and the public section_output_index.json.
This small figure-data archive is a selected plotting-data set, not the entire
scientific reference-output archive. Obtain the latter from release v0.6.2.
